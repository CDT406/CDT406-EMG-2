# ------------------- batch_train.py -------------------
import os
import re
import csv
import matplotlib.pyplot as plt
from run_train import run_training

# ----------- Base Paths -----------
data_dir = "output/ProcessedData"
model_dir = r"output/ProcessedData/WindowTest50%overlap"
os.makedirs(model_dir, exist_ok=True)

results_csv = os.path.join(model_dir, "training_summary.csv")
plot_path = os.path.join(model_dir, "accuracy_vs_window.png")

sequence_length = 3
results = []

# ----------- Train and Track Accuracies -----------
for fname in os.listdir(data_dir):
    if fname.endswith(".pkl"):
        data_path = os.path.join(data_dir, fname)
        model_name = fname.replace(".pkl", ".tflite")
        tflite_output_path = os.path.join(model_dir, model_name)

        print(f"\n🔁 Training model for: {fname}")
        accuracy, n_train, n_val = run_training(data_path, sequence_length, tflite_output_path)

        # Extract window/overlap from filename
        match = re.search(r"W(\d+)_O(\d+)", fname)
        window_size = int(match.group(1)) if match else -1
        overlap = int(match.group(2)) if match else -1

        results.append({
            "file": fname,
            "window": window_size,
            "overlap": overlap,
            "accuracy": accuracy,
            "train_samples": n_train,
            "val_samples": n_val,
            "model_path": tflite_output_path
        })

# ----------- Save CSV Summary -----------
with open(results_csv, 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=results[0].keys())
    writer.writeheader()
    writer.writerows(results)

print(f"\n✅ Training summary saved to {results_csv}")

# ----------- Plot Accuracy vs Window Size -----------
results.sort(key=lambda x: x["window"])
windows = [r["window"] for r in results]
accuracies = [r["accuracy"] * 100 for r in results]

plt.figure(figsize=(10, 5))
plt.plot(windows, accuracies, marker='o')
plt.title("Validation Accuracy vs Window Size (50% Overlap)")
plt.xlabel("Window Size")
plt.ylabel("Validation Accuracy (%)")
plt.grid(True)
plt.tight_layout()
plt.savefig(plot_path)
plt.show()

print(f"\n📊 Accuracy plot saved to {plot_path}")
